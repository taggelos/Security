<?php
                session_start();
        $dbname="SSSA100";
        session_register("dbname");
        include("../../modules/course_home/course_home.php");
        ?>