<?php
include '../../../config/config.php' ;

echo $mysqlPassword;
?>